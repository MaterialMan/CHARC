function plotUCNC19Results(figureHandle,resSize,directed)

dotSize= 5;
maxKR =0; maxGR=0;maxMC=0;

for p = 1:length(resSize)
    
    if resSize(p) == 25
        if directed
            ring25 = load('substrate_Ring_run10_gens2000_Nres_25_directed1_self1.mat','all_databases','total_space_covered');
            latt25 = load('substrate_Lattice_run10_gens2000_Nres_25_directed1_self1.mat','all_databases','total_space_covered');
            esn25 = load('noveltySearch3D_size25_run10_gens2000.mat','all_databases','total_space_covered');
        else
            ring25 = load('substrate_Ring_run10_gens2000_Nres_25_directed0_self1.mat','all_databases','total_space_covered');
            latt25 = load('substrate_Lattice_run10_gens2000_Nres_25_directed0_self1.mat','all_databases','total_space_covered');
            esn25 = load('noveltySearch3D_size25_run10_gens2000.mat','all_databases','total_space_covered');
        end
        
        %plot database
        [maxKR,maxGR,maxMC]=plotBS(figureHandle{1},{ring25.all_databases{10,10},latt25.all_databases{10,10},esn25.all_databases{10,10}},dotSize,maxKR,maxGR,maxMC,directed);
        print(strcat('UCNC19_behaviourSpace_direct',num2str(resSize(p))),'-dpdf','-bestfit')
        
        %plot quality measure
        plotQuality(figureHandle{2},{ring25.total_space_covered,latt25.total_space_covered,esn25.total_space_covered},{'25','25','25'},{' Ring',' Lattice',' ESN'},directed)
        legend('25-Ring(d)','25-Lattice(d)','25-ESN(d)','25-Ring(u)','25-Lattice(u)','Location','northwest')
        print(strcat('UCNC19_quality_direct',num2str(resSize(p))),'-dpdf','-bestfit')
        
        %plot quality/generation ratio
        plotQualityRatio(figureHandle{3},{ring25.total_space_covered,latt25.total_space_covered,esn25.total_space_covered},[25 25 25],{' Ring',' Lattice',' ESN'},directed)
        legend('25-Ring(d)','25-Lattice(d)','25-ESN(d)','25-Ring(u)','25-Lattice(u)','Location','northwest')
        print(strcat('UCNC19_qualityRatio_direct',num2str(resSize(p))),'-dpdf','-bestfit')
    end
    
    if resSize(p) == 50
        if directed
            ring50 = load('substrate_Ring_run10_gens2000_Nres_50_directed1_self1.mat','all_databases','total_space_covered');
            latt49 = load('substrate_Lattice_run10_gens2000_Nres_49_directed1_self1.mat','all_databases','total_space_covered');
            esn50 = load('noveltySearch3D_size50_run10_gens2000.mat','all_databases','total_space_covered');
        else
            ring50 = load('substrate_Ring_run10_gens2000_Nres_50_directed0_self1.mat','all_databases','total_space_covered');
            latt49 = load('substrate_Lattice_run10_gens2000_Nres_49_directed0_self1.mat','all_databases','total_space_covered');
            esn50 = load('noveltySearch3D_size50_run10_gens2000.mat','all_databases','total_space_covered');
        end
        
        %plot database
        [maxKR,maxGR,maxMC]=plotBS(figureHandle{1},{ring50.all_databases{10,10},latt49.all_databases{10,10},esn50.all_databases{10,10}},dotSize,maxKR,maxGR,maxMC,directed);
        print(strcat('UCNC19_behaviourSpace_direct',num2str(resSize(p))),'-dpdf','-bestfit')
        
        %plot quality measure
        plotQuality(figureHandle{2},{ring50.total_space_covered,latt49.total_space_covered,esn50.total_space_covered},{'50','49','50'},{' Ring',' Lattice',' ESN'},directed)
        legend('50-Ring(d)','50-Lattice(d)','50-ESN(d)','50-Ring(u)','50-Lattice(u)','Location','northwest')
        print(strcat('UCNC19_quality_direct',num2str(resSize(p))),'-dpdf','-bestfit')
        %plot quality/generation ratio
        plotQualityRatio(figureHandle{3},{ring50.total_space_covered,latt49.total_space_covered,esn50.total_space_covered},[50 49 50],{' Ring',' Lattice',' ESN'},directed)
        legend('50-Ring(d)','50-Lattice(d)','50-ESN(d)','50-Ring(u)','50-Lattice(u)','Location','northwest')
        print(strcat('UCNC19_qualityRatio_direct',num2str(resSize(p))),'-dpdf','-bestfit')
    end
    
    if resSize(p) == 100
        if directed
            ring100 = load('substrate_Ring_run10_gens2000_Nres_100_directed1_self1.mat','all_databases','total_space_covered');
            latt100 = load('substrate_Lattice_run10_gens2000_Nres_100_directed1_self1.mat','all_databases','total_space_covered');
            esn100 = load('noveltySearch3D_size100_run10_gens2000.mat','all_databases','total_space_covered');
        else
            ring100 = load('substrate_Ring_run10_gens2000_Nres_100_directed0_self1.mat','all_databases','total_space_covered');
            latt100 = load('substrate_Lattice_run10_gens2000_Nres_100_directed0_self1.mat','all_databases','total_space_covered');
            esn100 = load('noveltySearch3D_size100_run10_gens2000.mat','all_databases','total_space_covered');
        end
        
        %plot database
        [maxKR,maxGR,maxMC]=plotBS(figureHandle{1},{ring100.all_databases{10,10},latt100.all_databases{10,10},esn100.all_databases{10,10}},dotSize,maxKR,maxGR,maxMC,directed);
        print(strcat('UCNC19_behaviourSpace_direct',num2str(resSize(p))),'-dpdf','-bestfit')
        
        %plot quality measure
        plotQuality(figureHandle{2},{ring100.total_space_covered,latt100.total_space_covered,esn100.total_space_covered},{'100','100','100'},{' Ring',' Lattice',' ESN'},directed)
        legend('100-Ring(d)','100-Lattice(d)','100-ESN(d)','100-Ring(u)','100-Lattice(u)','Location','northwest')
        print(strcat('UCNC19_quality_direct',num2str(resSize(p))),'-dpdf','-bestfit')
        
        
        %plot quality/generation ratio
        plotQualityRatio(figureHandle{3},{ring100.total_space_covered,latt100.total_space_covered,esn100.total_space_covered},[100 100 100],{' Ring',' Lattice',' ESN'},directed)
        legend('100-Ring(d)','100-Lattice(d)','100-ESN(d)','100-Ring(u)','100-Lattice(u)','Location','northwest')
        print(strcat('UCNC19_qualityRatio_direct',num2str(resSize(p))),'-dpdf','-bestfit')
        
    end
    
    if resSize(p) == 200
        
        if directed
            ring200 = load('substrate_Ring_run10_gens2000_Nres_200_directed1_self1.mat','all_databases','total_space_covered');
            latt196 = load('substrate_Lattice_run10_gens2000_Nres_196_directed1_self1.mat','all_databases','total_space_covered');
            esn200 = load('noveltySearch3D_size200_run10_gens2000.mat','all_databases','total_space_covered');
        else
            ring200 = load('substrate_Ring_run10_gens2000_Nres_200_directed0_self1.mat','all_databases','total_space_covered');
            latt196 = load('substrate_Lattice_run10_gens2000_Nres_196_directed0_self1.mat','all_databases','total_space_covered');
            esn200 = load('noveltySearch3D_size200_run10_gens2000.mat','all_databases','total_space_covered');
        end
        
        %plot database
        [maxKR,maxGR,maxMC]=plotBS(figureHandle{1},{ring200.all_databases{10,10},latt196.all_databases{10,10},esn200.all_databases{10,10}},dotSize,maxKR,maxGR,maxMC,directed);
        print(strcat('UCNC19_behaviourSpace_direct',num2str(resSize(p))),'-dpdf','-bestfit')
        
        %plot quality measure
        plotQuality(figureHandle{2},{ring200.total_space_covered,latt196.total_space_covered,esn200.total_space_covered},{'200','196','200'},{' Ring',' Lattice',' ESN'},directed)
        legend('200-Ring(d)','196-Lattice(d)','200-ESN(d)','200-Ring(u)','196-Lattice(u)','Location','northwest')
        print(strcat('UCNC19_quality_direct',num2str(resSize(p))),'-dpdf','-bestfit')
        %plot quality/generation ratio
        plotQualityRatio(figureHandle{3},{ring200.total_space_covered,latt196.total_space_covered,esn200.total_space_covered},[200 196 200],{' Ring',' Lattice',' ESN'},directed)
        legend('200-Ring(d)','196-Lattice(d)','200-ESN(d)','200-Ring(u)','196-Lattice(u)','Location','northwest')
        print(strcat('UCNC19_qualityRatio_direct',num2str(resSize(p))),'-dpdf','-bestfit')
    end
    
    if resSize(p) == 400
        
        if directed
            ring400 = load('substrate_Ring_run10_gens2000_Nres_400_directed1_self1.mat','all_databases','total_space_covered');
            latt400 = load('substrate_Lattice_run10_gens2000_Nres_400_directed1_self1.mat','all_databases','total_space_covered');
            esn200 = load('noveltySearch3D_size200_run10_gens2000.mat','all_databases','total_space_covered');
        else
            ring400 = load('substrate_Ring_run10_gens2000_Nres_400_directed0_self1.mat','all_databases','total_space_covered');
            latt400 = load('substrate_Lattice_run10_gens2000_Nres_400_directed0_self1.mat','all_databases','total_space_covered');
            esn200 = load('noveltySearch3D_size200_run10_gens2000.mat','all_databases','total_space_covered');
        end
        
        %plot database
        [maxKR,maxGR,maxMC]=plotBS(figureHandle{1},{ring400.all_databases{10,10},latt400.all_databases{10,10},esn200.all_databases{10,10}},dotSize,maxKR,maxGR,maxMC,directed);
        print(strcat('UCNC19_behaviourSpace_direct',num2str(resSize(p))),'-dpdf','-bestfit')
        
        %plot quality measure
        plotQuality(figureHandle{2},{ring400.total_space_covered,latt400.total_space_covered,esn200.total_space_covered},{'400','400','400'},{' Ring',' Lattice',' ESN'},directed)
        legend('400-Ring(d)','400-Lattice(d)','200-ESN(d)','400-Ring(u)','400-Lattice(u)','Location','northwest')
        print(strcat('UCNC19_quality_direct',num2str(resSize(p))),'-dpdf','-bestfit')
        
        %plot quality/generation ratio
        plotQualityRatio(figureHandle{3},{ring400.total_space_covered,latt400.total_space_covered,esn200.total_space_covered},[400 400 400],{' Ring',' Lattice',' ESN'},directed)
        legend('400-Ring(d)','400-Lattice(d)','200-ESN(d)','400-Ring(u)','400-Lattice(u)','Location','northwest')
        print(strcat('UCNC19_qualityRatio_direct',num2str(resSize(p))),'-dpdf','-bestfit')
    end
    
end