
function plotIndvGraph(genotype,metrics,config)

%genotype = database_genotype;
%metrics = all_databases{1,10};

figure
c = 1:length(metrics);
dotSize = 5;

subplot(1,3,1)
scatter(metrics(:,1),metrics(:,2),dotSize,c,'filled')
xlabel('KR')
ylabel('GR')

subplot(1,3,2)
scatter(metrics(:,1),metrics(:,3),dotSize,c,'filled')
xlabel('KR')
ylabel('MC')

subplot(1,3,3)%+(i-1)*3)
scatter(metrics(:,2),metrics(:,3),dotSize,c,'filled')
xlabel('GR')
ylabel('MC')


%% select individual from map
subplot(1,3,2)
h = imrect;
xy = h.getPosition;
handleStateChange(xy,metrics,dotSize);
%h.addNewPositionCallback(h,@(newpos) handleStateChange(newpos,metrics,dotSize));



desired_metric = [10,10,10];
[~,order_m] = sort(sum((metrics-desired_metric).^2,2));
inOrderM = metrics(order_m,:);
best_indv = order_m(1);

%

figure
if config.plot3d
    p = plot(genotype(best_indv).G,'NodeLabel',{},'Layout','force3');
else
    p = plot(genotype(best_indv).G,'NodeLabel',{},'Layout','force');
end
p.NodeColor = 'black';
p.MarkerSize = 5;
p.EdgeColor = 'k';
% if ~config.directedGraph
%     p.EdgeCData = genotype(best_indv).G.Edges.Weight;
% end
% highlight(p,logical(genotype(best_indv).input_loc),'NodeColor','g','MarkerSize',3)
% colormap(bluewhitered)
set(gcf,'renderer','OpenGL')
set(gca,'visible','off')

end


function handleStateChange(xy,metrics,dotSize)

%xy = h.getPosition;
c = 1:length(metrics);
list = [];
for i = 1:length(metrics)
    if metrics(i,1) > xy(1) && metrics(i,1) < xy(3) && metrics(i,3) > xy(2) && metrics(i,3) < xy(4)
        list = [list; metrics(i,:)];
        c(i) = 0;
    end
end


%replot
subplot(1,3,1)
scatter(metrics(:,1),metrics(:,2),dotSize,c,'filled')
xlabel('KR')
ylabel('GR')

subplot(1,3,2)
scatter(metrics(:,1),metrics(:,3),dotSize,c,'filled')
xlabel('KR')
ylabel('MC')
h = imrect(gca,xy);
h.addNewPositionCallback(@(newpos) handleStateChange(newpos,metrics,dotSize));


subplot(1,3,3)
scatter(metrics(:,2),metrics(:,3),dotSize,c,'filled')
xlabel('GR')
ylabel('MC')

end
